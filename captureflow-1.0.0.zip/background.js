const se = "captureflow.popup-window.v1";
async function _e() {
  return (await chrome.storage.session.get(se))[se];
}
async function ht(e) {
  if (e.id !== chrome.runtime.id || e.url?.split("?")[0] !== chrome.runtime.getURL("popup.html"))
    throw new Error("Untrusted window request.");
  const t = await _e();
  if (t)
    try {
      const n = await chrome.windows.get(t.windowId, { populate: !0 });
      if (n.type === "popup" && n.tabs?.some((c) => c.url === chrome.runtime.getURL("popup.html?detached=1"))) {
        await chrome.windows.update(t.windowId, { focused: !0 });
        return;
      }
    } catch {
    }
  const [o] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  if (o?.windowId === void 0)
    throw new Error("Open CaptureFlow from a browser window first.");
  const r = await chrome.windows.create({
    url: chrome.runtime.getURL("popup.html?detached=1"),
    type: "popup",
    width: 420,
    height: 640,
    focused: !0
  });
  if (r?.id === void 0) throw new Error("Chrome could not create the CaptureFlow window.");
  await chrome.storage.session.set({
    [se]: { windowId: r.id, sourceWindowId: o.windowId }
  });
}
async function wt(e) {
  if (e < 0) return;
  const t = await _e();
  if (!t || t.windowId === e) return;
  (await chrome.windows.get(e)).type === "normal" && await chrome.storage.session.set({ [se]: { ...t, sourceWindowId: e } });
}
async function Le(e) {
  if (new URL(e.url ?? chrome.runtime.getURL("popup.html")).searchParams.get("detached") !== "1")
    return (await chrome.tabs.query({ active: !0, currentWindow: !0 }))[0];
  const t = await _e();
  if (!t || e.tab?.windowId !== t.windowId)
    throw new Error("Reopen the CaptureFlow window from the browser toolbar.");
  let o;
  try {
    o = (await chrome.tabs.query({ active: !0, windowId: t.sourceWindowId }))[0];
  } catch {
  }
  if (!o) {
    const r = await chrome.windows.getAll({ windowTypes: ["normal"] }), n = r.find((c) => c.focused) ?? r[0];
    n?.id !== void 0 && (o = (await chrome.tabs.query({ active: !0, windowId: n.id }))[0]);
  }
  if (!o) throw new Error("Open a webpage in a Chrome browser window first.");
  return await chrome.windows.update(o.windowId, { focused: !0 }), o;
}
const ft = "captureflow.window", mt = !0, gt = {
  enabled: mt
}, yt = "captureflow.auth", te = "captureflow.auth.v1", le = "captureflow.guest.v1";
function ie(e) {
  const t = e.trim();
  return t ? t.length > 254 || !/^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/.test(t) ? "Enter a valid email address, for example name@example.com." : "" : "Enter your email address.";
}
function oe(e) {
  return e.length < 6 ? "Use at least 6 characters for your password." : e.length > 128 ? "Use no more than 128 characters for your password." : /[A-Z]/.test(e) ? /[0-9]/.test(e) ? /[^\p{L}\p{N}\s]/u.test(e) ? "" : "Include at least one special character, such as !, @ or #." : "Include at least one number." : "Include at least one uppercase letter.";
}
const bt = "https://captureflow-billing.captureflow-billing.workers.dev", Et = { kty: "EC", x: "ZnqEBzEbbg6uxm5fcmq6TzxLEOlOSzjTVnDQBBTx4Jk", y: "SLMq1o-4V4V9a3FordCrX5ExsjnwwP04ZJVBIt5wSgU", crv: "P-256" }, vt = {
  apiOrigin: bt,
  publicKey: Et
}, b = vt;
function ue() {
  return /^https:\/\/[a-z0-9.-]+$/.test(b.apiOrigin) && b.publicKey?.kty === "EC";
}
class tt extends Error {
  constructor(t, o) {
    super(o), this.status = t, this.name = "BillingHttpError";
  }
  status;
}
async function Re(e, t, o) {
  if (!ue())
    throw new Error("Automatic subscription activation is not configured yet.");
  const r = await fetch(b.apiOrigin + e, {
    method: o ? "POST" : "GET",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + t },
    ...o ? { body: JSON.stringify(o) } : {},
    credentials: "omit",
    cache: "no-store",
    redirect: "error",
    referrerPolicy: "no-referrer",
    signal: AbortSignal.timeout(25e3)
  }), n = await r.json();
  if (!r.ok)
    throw new tt(
      r.status,
      n && typeof n == "object" && "error" in n && typeof n.error == "string" ? n.error.slice(0, 240) : "Subscription service is temporarily unavailable."
    );
  return n;
}
function ve() {
  return typeof chrome < "u" && !!chrome.runtime?.id;
}
const M = "captureflow.billing.v1";
let K = null, J = { plan: "basic", paidUntil: 0 }, Be = 0, Ge = 0;
const St = /* @__PURE__ */ new Set(), Te = (e) => Uint8Array.from(atob(e.replaceAll("-", "+").replaceAll("_", "/")), (t) => t.charCodeAt(0)), rt = (e) => btoa(String.fromCharCode(...e)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
async function Tt(e) {
  return rt(
    new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(e)))
  );
}
async function de(e, t, o, r, n = Date.now()) {
  if (e.length > 4096 || !/^[A-Za-z0-9_-]{43}$/.test(t))
    throw new Error("Invalid license data.");
  const c = e.split(".");
  if (c.length !== 3 || c.some((g) => !/^[A-Za-z0-9_-]+$/.test(g)))
    throw new Error("Invalid license signature.");
  const [i, s, a] = c, d = JSON.parse(new TextDecoder().decode(Te(i)));
  if (d.alg !== "ES256" || d.typ !== "JWT")
    throw new Error("Unsupported license signature.");
  const l = await crypto.subtle.importKey(
    "jwk",
    r,
    { name: "ECDSA", namedCurve: "P-256" },
    !1,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    l,
    Te(a),
    new TextEncoder().encode(i + "." + s)
  ))
    throw new Error("License signature verification failed.");
  const u = JSON.parse(new TextDecoder().decode(Te(s))), w = Math.floor(n / 1e3);
  if (u.iss !== o || u.aud !== "captureflow" || u.sub !== await Tt(t) || !["basic", "pro"].includes(u.plan) || !Number.isSafeInteger(u.iat) || !Number.isSafeInteger(u.exp) || !Number.isSafeInteger(u.paidUntil) || u.paidUntil < 0 || u.iat > w + 300 || u.exp <= w || u.exp <= u.iat || u.exp - u.iat > 21600 || (u.source === "admin" ? u.plan !== "pro" || u.paidUntil !== 0 || u.exp - u.iat > 600 : u.plan === "pro" && (u.paidUntil <= n || u.exp * 1e3 > u.paidUntil)))
    throw new Error("This license has expired or belongs to another installation.");
  return u;
}
function ot() {
  const e = Be = Math.max(Be, Date.now()), t = K?.plan === "pro" && K.exp * 1e3 > e && (K.source === "admin" || K.paidUntil > e) ? "pro" : "basic", o = K?.paidUntil ?? 0;
  if (J.plan !== t || J.paidUntil !== o) {
    J = { plan: t, paidUntil: o };
    for (const r of St) r();
  }
}
function nt() {
  return ot(), J.plan;
}
function At() {
  return J;
}
async function pe() {
  if (!ve()) return null;
  if (!chrome.storage?.local) {
    const t = await chrome.runtime.sendMessage({
      channel: "captureflow.billing",
      type: "CACHED"
    });
    return t?.ok ? t.data : null;
  }
  const e = (await chrome.storage.local.get(M))[M];
  return !e || typeof e.recoveryKey != "string" || !/^[A-Za-z0-9_-]{43}$/.test(e.recoveryKey) ? null : {
    recoveryKey: e.recoveryKey,
    entitlement: typeof e.entitlement == "string" ? e.entitlement : "",
    checkedAt: typeof e.checkedAt == "number" ? e.checkedAt : 0,
    checkoutPending: e.checkoutPending === !0
  };
}
async function k() {
  if (!ue()) return;
  const e = ++Ge;
  let t = null;
  try {
    const o = await pe();
    o?.entitlement && b.publicKey && (t = await de(
      o.entitlement,
      o.recoveryKey,
      b.apiOrigin,
      b.publicKey
    ));
  } catch {
  }
  Ge === e && (K = t, ot());
}
async function ae(e) {
  await chrome.storage.local.remove(te), await chrome.storage.local.remove(M), await chrome.storage.local.set({ [le]: e }), await k();
}
async function N(...e) {
  try {
    return await Re(...e);
  } catch (t) {
    const o = e[2]?.operation;
    throw t instanceof tt && t.status === 401 && o !== "login" && o !== "register" && await ae(!1), t;
  }
}
async function $() {
  const e = (await chrome.storage.local.get(te))[te];
  return !e || typeof e.idToken != "string" || typeof e.refreshToken != "string" || typeof e.uid != "string" || typeof e.email != "string" || typeof e.expiresAt != "number" ? null : e;
}
async function it(e) {
  if (!e.idToken || !e.refreshToken || !e.uid || !Number.isFinite(e.expiresAt) || ie(e.email))
    throw new Error("The account service returned an invalid session. Please log in again.");
  await chrome.storage.local.set({ [te]: e, [le]: !1 });
}
async function Q(e, t = !1) {
  if (!e.emailVerified) return;
  const o = await pe(), r = await N("/v1/account", e.idToken, {
    previousKey: o?.recoveryKey ?? ""
  });
  if (!b.publicKey) throw new Error("Subscription verification is not configured.");
  if (t) {
    o?.recoveryKey !== r.recoveryKey && await chrome.storage.local.set({
      [M]: {
        recoveryKey: r.recoveryKey,
        entitlement: "",
        checkedAt: 0
      }
    }), await k();
    return;
  }
  const n = await N("/v1/license", r.recoveryKey);
  if (!b.publicKey) throw new Error("Subscription verification is not configured.");
  await de(
    n.entitlement,
    r.recoveryKey,
    b.apiOrigin,
    b.publicKey
  ), await chrome.storage.local.set({
    [M]: {
      recoveryKey: r.recoveryKey,
      entitlement: n.entitlement,
      checkedAt: Date.now(),
      checkoutPending: o?.recoveryKey === r.recoveryKey && o.checkoutPending === !0
    }
  }), await k();
}
async function B(e = !1) {
  let t = await $();
  return t ? ((e || t.expiresAt < Date.now() + 6e4) && (t = await N("/v1/auth", "", {
    operation: "refresh",
    refreshToken: t.refreshToken
  }), await it(t)), t) : null;
}
async function It() {
  const e = await B(!0);
  if (!e) throw new Error("Log in to your CaptureFlow account before subscribing to Pro.");
  if (!e.emailVerified)
    throw new Error("Confirm your email first. Open Login to resend the verification email.");
  return await Q(e, !0), e.idToken;
}
async function We(e, t) {
  const o = t.url?.split("?")[0];
  if (t.id !== chrome.runtime.id || !["popup.html"].some((i) => o === chrome.runtime.getURL(i)))
    throw new Error("Untrusted account request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid account request.");
  const r = e;
  if (r.type === "LOGOUT" || r.type === "GUEST")
    await ae(r.type === "GUEST");
  else if (r.type !== "STATUS")
    if (["LOGIN", "REGISTER", "RESET"].includes(String(r.type))) {
      const i = typeof r.email == "string" ? r.email.trim() : "";
      if (ie(i)) throw new Error(ie(i));
      if (r.type === "REGISTER" && oe(typeof r.password == "string" ? r.password : ""))
        throw new Error(oe(typeof r.password == "string" ? r.password : ""));
      if (r.type !== "RESET" && (typeof r.password != "string" || !r.password || r.password.length > 128))
        throw new Error("Enter your password.");
      if (r.type === "RESET")
        await N("/v1/auth", "", { operation: "reset", email: i }), await ae(!1);
      else {
        const s = await N(
          "/v1/auth",
          "",
          {
            operation: r.type === "LOGIN" ? "login" : "register",
            ...r.type === "REGISTER" ? { sendVerification: "true" } : {},
            email: i,
            password: r.password
          }
        ), a = await $();
        if (a && a.uid !== s.uid && (await chrome.storage.local.remove(M), await k()), r.type === "REGISTER") {
          if (await ae(!1), s.verificationEmailSent !== !0)
            throw new Error(
              s.emailVerified ? "Your email is already verified. Log in to continue." : "Your account was created, but email sending was not confirmed. Log in and use Resend verification email."
            );
        } else
          await it(s), await Q(s);
      }
    } else if (r.type === "RESET_FINISH") {
      if (typeof r.email != "string" || ie(r.email))
        throw new Error("Enter a valid email address.");
      if (typeof r.password != "string" || oe(r.password))
        throw new Error(oe(typeof r.password == "string" ? r.password : ""));
      await N("/v1/auth", "", {
        operation: "resetFinish",
        email: r.email.trim(),
        password: r.password,
        link: typeof r.link == "string" ? r.link : ""
      }), (await $())?.email.toLowerCase() === r.email.trim().toLowerCase() && (await chrome.storage.local.remove(te), await chrome.storage.local.remove(M), await k());
    } else if (r.type === "VERIFY_FINISH") {
      const i = await B();
      if (!i) throw new Error("Please log in again.");
      await N("/v1/auth", "", {
        operation: "verifyFinish",
        idToken: i.idToken,
        link: typeof r.link == "string" ? r.link : ""
      });
      const s = await B(!0);
      s && await Q(s);
    } else if (r.type === "RESUME") {
      const i = await B(!0);
      i && await Q(i);
    } else if (r.type === "VERIFY") {
      const i = await B();
      if (!i) throw new Error("Please log in again.");
      const s = await N("/v1/auth", "", { operation: "verify", idToken: i.idToken });
      if (s.alreadyVerified) {
        const a = await B(!0);
        a && await Q(a);
      } else if (s.sent !== !0 || s.email?.trim().toLowerCase() !== i.email.trim().toLowerCase())
        throw new Error("The email service did not confirm sending. Please try again.");
    } else throw new Error("Unknown account command.");
  const n = await $(), c = (await chrome.storage.local.get(le))[le] === !0;
  return {
    configured: gt.enabled,
    guest: c,
    user: n ? { email: n.email, emailVerified: n.emailVerified } : null
  };
}
const Ct = "captureflow.billing";
async function kt(e, t) {
  if (t.id !== chrome.runtime.id || !t.url?.startsWith(chrome.runtime.getURL("")) || t.tab && !["popup.html", "capture.html", "history.html", "recording.html"].some(
    (a) => t.url.split("?")[0] === chrome.runtime.getURL(a)
  ))
    throw new Error("Untrusted billing request.");
  if (!e || typeof e != "object" || !("type" in e))
    throw new Error("Invalid billing command.");
  const o = e;
  let r = await pe();
  const c = (await $())?.emailVerified === !0, i = () => ({
    configured: ue(),
    plan: nt(),
    paidUntil: At().paidUntil,
    recoveryKey: c ? r?.recoveryKey ?? "" : "",
    checkedAt: r?.checkedAt ?? 0,
    checkoutPending: c && r?.checkoutPending === !0
  });
  if (await k(), o.type === "STATUS") return i();
  if (o.type === "CACHED") return r;
  if (o.type === "REFRESH" && !c) return i();
  if (!ue() || !b.publicKey)
    throw new Error("Automatic subscription activation is not configured yet.");
  const s = async (a) => {
    await chrome.storage.local.set({ [M]: a }), r = a, await k();
  };
  if (o.type === "REFRESH" && r && r.checkedAt > Date.now() - 1e4)
    try {
      return await de(
        r.entitlement,
        r.recoveryKey,
        b.apiOrigin,
        b.publicKey
      ), i();
    } catch {
    }
  if (o.type === "REFRESH" || o.type === "RESTORE") {
    const a = o.type === "RESTORE" && typeof o.key == "string" ? o.key.trim().replace(/^CF-/, "") : r?.recoveryKey;
    if (!a || !/^[A-Za-z0-9_-]{43}$/.test(a))
      throw new Error("Enter a valid CaptureFlow recovery key.");
    const d = await Re(
      "/v1/license",
      a
    ), l = await de(
      d.entitlement,
      a,
      b.apiOrigin,
      b.publicKey
    );
    return await s({
      recoveryKey: a,
      entitlement: d.entitlement,
      checkedAt: Date.now(),
      checkoutPending: l.plan !== "pro" && o.type === "REFRESH" && r?.checkoutPending === !0
    }), { ...i(), verificationPending: d.verificationPending === !0 };
  }
  if (o.type === "CHECKOUT") {
    const a = await It();
    if (r = await pe(), o.plan !== "monthly" && o.plan !== "yearly")
      throw new Error("Choose a monthly or yearly plan.");
    r || await s({
      recoveryKey: rt(crypto.getRandomValues(new Uint8Array(32))),
      entitlement: "",
      checkedAt: 0
    });
    const d = r.recoveryKey, l = await Re("/v1/checkout", d, {
      plan: o.plan,
      ...a ? { idToken: a } : {}
    }), u = new URL(l.url);
    if (u.protocol !== "https:" || !["www.paypal.com", "www.sandbox.paypal.com"].includes(u.hostname) || u.username || u.password || u.port)
      throw new Error("Unexpected PayPal checkout address.");
    return await s({ ...r, checkoutPending: !0, checkedAt: 0 }), await chrome.tabs.create({ url: u.href }), i();
  }
  if (o.type === "FORGET")
    return await chrome.storage.local.remove(M), r = null, await k(), i();
  throw new Error("Unknown billing command.");
}
const xt = "captureflow/history/v1";
function Pt(e) {
  const t = e && typeof e == "object" ? e : null, o = typeof t?.message == "string" ? t.message : "Local history is unavailable. Try again.";
  return t?.name === "QuotaExceededError" || /quota/i.test(o) ? "Local history storage is full. Download this capture, delete unneeded history or free disk space, then try Save to history again." : o;
}
const Me = {
  basic: {
    label: "Basic",
    screenshots: 100,
    videos: 10,
    maxVideoMs: 3e5,
    editor: !1,
    adjustableQuality: !1,
    imageWidth: 1920
  },
  pro: {
    label: "Pro",
    screenshots: 1 / 0,
    videos: 1 / 0,
    maxVideoMs: 1 / 0,
    editor: !0,
    adjustableQuality: !0,
    imageWidth: 1 / 0
  }
};
function at() {
  return nt();
}
function Ae(e, t = at()) {
  return Me[t].adjustableQuality ? { ...e } : { ...e, quality: "standard" };
}
const Z = "captureflow.usage.v1";
function Ut(e = /* @__PURE__ */ new Date()) {
  return e.toISOString().slice(0, 7);
}
function Ve(e, t = /* @__PURE__ */ new Date()) {
  const o = Ut(t), r = e && typeof e == "object" ? e : {}, n = typeof r.month == "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(r.month) ? r.month : "";
  if (n < o) return { month: o, screenshots: [], videos: [] };
  const c = (i) => Array.isArray(r[i]) ? [
    ...new Set(
      r[i].filter(
        (s) => typeof s == "string" && s.length > 0
      )
    )
  ] : [];
  return { month: n, screenshots: c("screenshots"), videos: c("videos") };
}
async function he(e = /* @__PURE__ */ new Date()) {
  try {
    if (ve())
      return Ve((await chrome.storage.local.get(Z))[Z], e);
    const t = localStorage.getItem(Z);
    return Ve(t ? JSON.parse(t) : null, e);
  } catch {
    throw new Error("Monthly usage could not be read. Reopen CaptureFlow and try again.");
  }
}
function we(e, t, o, r = at()) {
  const n = t === "screenshot" ? e.screenshots : e.videos;
  if (o && n.includes(o)) return;
  const c = t === "screenshot" ? Me[r].screenshots : Me[r].videos;
  if (n.length >= c)
    throw new Error(
      "Basic monthly limit reached: " + c + (t === "screenshot" ? " screenshots" : " videos") + ". Limits reset on the first day of each month (UTC)."
    );
}
async function ct(e, t, o = /* @__PURE__ */ new Date()) {
  if (!t) throw new Error("Missing capture identifier.");
  const r = await he(o);
  we(r, e, t);
  const n = e === "screenshot" ? r.screenshots : r.videos;
  if (n.includes(t)) return r;
  n.push(t);
  try {
    ve() ? await chrome.storage.local.set({ [Z]: r }) : localStorage.setItem(Z, JSON.stringify(r));
  } catch {
    throw new Error("Monthly usage could not be saved. Check available browser storage.");
  }
  return r;
}
async function ze(e, t = !0) {
  if (e.controlsWindowId != null)
    try {
      return await chrome.windows.update(
        e.controlsWindowId,
        t ? { focused: !0, state: "normal", width: 280, height: 106 } : { width: 280, height: 106 }
      ), e;
    } catch {
    }
  const o = await chrome.windows.create({
    url: chrome.runtime.getURL("controls.html?id=" + encodeURIComponent(e.id)),
    type: "popup",
    width: 280,
    height: 106,
    focused: t
  });
  if (o?.id === void 0)
    throw new Error(
      "Chrome could not open recording controls. Use the extension popup to control this recording."
    );
  return {
    ...e,
    controlsWindowId: o.id,
    controlsTabId: o.tabs?.[0]?.id ?? null,
    controlsOpened: !0,
    controlsError: ""
  };
}
async function Ie(e) {
  if (e.controlsWindowId != null)
    try {
      await chrome.windows.remove(e.controlsWindowId);
    } catch {
    }
}
const R = Object.freeze({
  schemaVersion: 1,
  theme: "dark",
  screenshotFormat: "png",
  jpegQuality: 90,
  filename: "CaptureFlow",
  recordingMode: "tab",
  recordingQuality: "high",
  microphone: !1,
  autoSave: !0
});
function Ye(e) {
  const t = typeof e == "object" && e !== null ? e : {}, o = (n, c, i) => c.includes(n) ? n : i, r = typeof t.filename == "string" ? t.filename.trim().replace(/[<>:"/\\|?*\u0000-\u001f]/g, "").slice(0, 80) : "";
  return {
    schemaVersion: 1,
    theme: o(t.theme, ["dark", "light", "system"], R.theme),
    screenshotFormat: o(
      t.screenshotFormat,
      ["png", "jpeg"],
      R.screenshotFormat
    ),
    jpegQuality: typeof t.jpegQuality == "number" && Number.isFinite(t.jpegQuality) ? Math.max(10, Math.min(100, Math.round(t.jpegQuality))) : R.jpegQuality,
    filename: r || R.filename,
    recordingMode: o(
      t.recordingMode,
      ["tab", "window", "screen"],
      R.recordingMode
    ),
    recordingQuality: o(
      t.recordingQuality,
      ["standard", "high", "maximum"],
      R.recordingQuality
    ),
    // Retained for older stored records; voice capture is disabled.
    microphone: !1,
    autoSave: typeof t.autoSave == "boolean" ? t.autoSave : R.autoSave
  };
}
const Ce = "captureflow.settings.v1";
async function qe() {
  if (ve()) {
    const t = await chrome.storage.local.get(Ce);
    return Ye(t[Ce]);
  }
  const e = localStorage.getItem(Ce);
  try {
    return Ye(e ? JSON.parse(e) : R);
  } catch {
    return { ...R };
  }
}
const Lt = "captureflow.recordings.v1", Rt = 2;
function Mt() {
  return new Promise((e, t) => {
    let o = !1;
    const r = indexedDB.open(Lt, Rt);
    r.onupgradeneeded = () => {
      const n = r.result;
      n.objectStoreNames.contains("recordings") || n.createObjectStore("recordings", { keyPath: "id" }), n.objectStoreNames.contains("chunks") || n.createObjectStore("chunks", { keyPath: ["id", "index"] }).createIndex("recording", "id"), n.objectStoreNames.contains("screenshots") || n.createObjectStore("screenshots", { keyPath: "id" }), n.objectStoreNames.contains("assets") || n.createObjectStore("assets", { keyPath: ["id", "kind"] }).createIndex("capture", "id");
    }, r.onerror = () => t(r.error ?? new Error("Local capture storage is unavailable.")), r.onblocked = () => {
      o = !0, t(new Error("Close other CaptureFlow pages and retry the history upgrade."));
    }, r.onsuccess = () => {
      const n = r.result;
      if (o) {
        n.close();
        return;
      }
      n.onversionchange = () => n.close(), e(n);
    };
  });
}
async function x(e, t, o) {
  const r = await Mt();
  try {
    return await new Promise((n, c) => {
      const i = r.transaction(e, t);
      let s, a = null;
      i.oncomplete = () => n(s), i.onabort = () => c(a ?? i.error ?? new Error("Local capture storage transaction failed.")), i.onerror = () => {
      };
      const d = (l) => {
        a = l, i.abort();
      };
      try {
        o(
          i,
          (l) => {
            s = l;
          },
          d
        );
      } catch (l) {
        a = l instanceof Error ? l : new Error("Local history operation failed."), i.abort();
      }
    });
  } finally {
    r.close();
  }
}
function fe(e, t) {
  const o = e.objectStore("assets").index("capture").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("assets").delete(r.primaryKey), r.continue());
  };
}
function Oe(e, t) {
  const o = e.objectStore("chunks").index("recording").openKeyCursor(IDBKeyRange.only(t));
  o.onsuccess = () => {
    const r = o.result;
    r && (e.objectStore("chunks").delete(r.primaryKey), r.continue());
  };
}
async function Nt(e) {
  await x(["recordings"], "readwrite", (t) => {
    t.objectStore("recordings").put(e);
  });
}
async function me(e) {
  return x(["recordings"], "readonly", (t, o) => {
    const r = t.objectStore("recordings").get(e);
    r.onsuccess = () => o(r.result ?? null);
  });
}
async function Ft() {
  return x(["recordings"], "readonly", (e, t) => {
    const o = e.objectStore("recordings").getAll();
    o.onsuccess = () => t(o.result.sort((r, n) => n.createdAt - r.createdAt));
  });
}
async function _t(e, t) {
  return x(["chunks"], "readonly", (o, r) => {
    const n = o.objectStore("chunks").index("recording").getAll(IDBKeyRange.only(e));
    n.onsuccess = () => {
      const c = n.result;
      if (c.sort((i, s) => i.index - s.index), !c.length) {
        r(new Blob([], { type: t }));
        return;
      }
      r(
        new Blob(
          c.map((i) => i.blob),
          { type: t }
        )
      );
    };
  });
}
async function Ot(e) {
  return x(["recordings"], "readwrite", (t, o, r) => {
    const n = t.objectStore("recordings"), c = n.get(e);
    c.onsuccess = () => {
      const i = c.result;
      if (!i) {
        r(new Error("This temporary recording has already been removed."));
        return;
      }
      const s = { ...i, retention: "saved" };
      n.put(s), o(s);
    };
  });
}
async function Dt(e, t) {
  await x(["recordings"], "readwrite", (o) => {
    const r = o.objectStore("recordings"), n = r.get(e);
    n.onsuccess = () => {
      const c = n.result;
      c?.retention === "temporary" && r.put({ ...c, previewTabId: t });
    };
  });
}
async function Ht(e) {
  return x(["recordings", "chunks", "assets"], "readwrite", (t, o) => {
    let r = 0;
    const n = t.objectStore("recordings").openCursor();
    n.onsuccess = () => {
      const c = n.result;
      if (!c) {
        o(r);
        return;
      }
      const i = c.value;
      i.retention === "temporary" && !e.has(i.id) && (c.delete(), Oe(t, i.id), fe(t, i.id), r++), c.continue();
    };
  });
}
const Qe = "captureflow.history.changed";
function ce() {
  typeof window < "u" && window.dispatchEvent(new Event(Qe));
  try {
    if (typeof BroadcastChannel == "function") {
      const e = new BroadcastChannel(Qe);
      e.postMessage("changed"), e.close();
    }
  } catch {
  }
}
const jt = "captureflow/recording/v1", Kt = "captureflow/recording-host/v1", Ne = "captureflow.recording.v1", C = (e) => !!e && ["setup", "starting", "recording", "paused", "stopping"].includes(e.status);
function Bt(e, t = Date.now()) {
  return Math.max(
    0,
    e.elapsedMs + (e.clockStartedAt === null ? 0 : Math.max(0, t - e.clockStartedAt))
  );
}
function ke(e) {
  if (!e || typeof e != "object") throw new Error("Invalid recording options.");
  const t = e;
  if (!["tab", "window", "screen"].includes(String(t.mode)) || !["standard", "high", "maximum"].includes(String(t.quality)) || typeof t.microphone != "boolean" || typeof t.audio != "boolean")
    throw new Error("Invalid recording options.");
  return {
    mode: t.mode,
    quality: t.quality,
    microphone: !1,
    audio: t.audio
  };
}
const Xe = 32760, Gt = 64e6;
function ge(e, t) {
  if (![e, t].every(Number.isSafeInteger) || e < 1 || t < 1)
    throw new Error("The screenshot has invalid dimensions.");
  if (e > Xe || t > Xe || e * t > Gt)
    throw new Error(
      "This page exceeds the safe screenshot size (32,760 pixels per side or 64 megapixels). Try a selected area or reduce browser zoom."
    );
}
function ee(e) {
  let t;
  try {
    t = new URL(e);
  } catch {
    throw new Error("Open a normal website before capturing.");
  }
  if (!["http:", "https:"].includes(t.protocol) || t.hostname === "chromewebstore.google.com" || t.hostname === "chrome.google.com" && t.pathname.startsWith("/webstore"))
    throw new Error(
      "Chrome protects this page. Open an ordinary HTTP or HTTPS webpage to capture it."
    );
  if (t.hostname === "chromewebstore.google.com")
    throw new Error("Chrome Web Store pages cannot be captured by CaptureFlow.");
}
function De(e) {
  if (!e || ![
    e.width,
    e.height,
    e.documentWidth,
    e.documentHeight,
    e.scrollX,
    e.scrollY,
    e.dpr,
    e.visualScale
  ].every(Number.isFinite) || e.width <= 0 || e.height <= 0 || e.dpr <= 0)
    throw new Error("The page returned invalid viewport dimensions.");
  if (Math.abs(e.visualScale - 1) > 0.01)
    throw new Error("Reset pinch zoom before capturing this page. Browser zoom is supported.");
}
function st(e, t, o, r) {
  if (De(t), !e || ![e.x, e.y, e.width, e.height].every(Number.isFinite) || e.width < 2 || e.height < 2 || e.x < 0 || e.y < 0 || e.x + e.width > t.width + 0.5 || e.y + e.height > t.height + 0.5)
    throw new Error("Select a valid area at least 2 × 2 pixels inside the viewport.");
  const n = o / t.width, c = r / t.height, i = Math.max(0, Math.round(e.x * n)), s = Math.max(0, Math.round(e.y * c)), a = Math.min(o, Math.round((e.x + e.width) * n)), d = Math.min(r, Math.round((e.y + e.height) * c)), l = { x: i, y: s, width: a - i, height: d - s };
  return ge(l.width, l.height), l;
}
function Je(e, t) {
  return Math.abs(e.width - t.width) < 0.5 && Math.abs(e.height - t.height) < 0.5 && Math.abs(e.dpr - t.dpr) < 1e-3 && Math.abs(e.scrollX - t.scrollX) < 1 && Math.abs(e.scrollY - t.scrollY) < 1;
}
async function Wt(e, t = !1) {
  const o = window;
  if (t) {
    o.__captureFlowFullSnapshot?.id === e && o.__captureFlowFullSnapshot.cleanup();
    return;
  }
  if (Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight ?? 0) <= innerHeight + 2 && Array.from(document.querySelectorAll("body *")).some((l) => {
    const u = l.getBoundingClientRect();
    return /auto|scroll/.test(getComputedStyle(l).overflowY) && l.scrollHeight > l.clientHeight + 50 && u.width * u.height > innerWidth * innerHeight * 0.5;
  }))
    throw new Error(
      "Nested scrolling pages are not supported. Use a visible or selected-area capture."
    );
  if (o.__captureFlowFullSnapshot)
    throw new Error("A full-page snapshot is already preparing this page.");
  const r = Array.from(document.images).filter((l) => l.loading === "lazy"), n = r.map((l) => ({ image: l, value: l.getAttribute("loading") })), c = document.createElement("style");
  c.textContent = "*,*::before,*::after{animation-play-state:paused!important;transition:none!important;overflow-anchor:none!important;}", document.documentElement.append(c);
  const i = Array.from(document.querySelectorAll("body *")).filter((l) => getComputedStyle(l).contentVisibility === "auto").map((l) => ({
    element: l,
    value: l.style.getPropertyValue("content-visibility"),
    priority: l.style.getPropertyPriority("content-visibility")
  }));
  for (const { element: l } of i)
    l.style.setProperty("content-visibility", "visible", "important");
  let s;
  const a = () => {
    clearTimeout(s), c.remove();
    for (const { element: l, value: u, priority: w } of i)
      u ? l.style.setProperty("content-visibility", u, w) : l.style.removeProperty("content-visibility");
    for (const { image: l, value: u } of n)
      u === null ? l.removeAttribute("loading") : l.setAttribute("loading", u);
    o.__captureFlowFullSnapshot?.id === e && delete o.__captureFlowFullSnapshot;
  };
  o.__captureFlowFullSnapshot = { id: e, cleanup: a }, s = setTimeout(a, 3e4);
  for (const l of r) l.loading = "eager";
  let d;
  try {
    await Promise.race([
      Promise.all(
        Array.from(document.images).map(
          (l) => l.complete ? Promise.resolve() : l.decode().catch(() => {
          })
        )
      ),
      new Promise((l) => {
        d = setTimeout(l, 1500);
      })
    ]);
  } finally {
    clearTimeout(d);
  }
}
async function He(e, t) {
  try {
    const o = window, r = () => new Promise((a, d) => {
      const l = setTimeout(
        () => d(
          new Error(
            "The source page stopped rendering. Keep its tab and window visible, then retry."
          )
        ),
        1e3
      );
      requestAnimationFrame(
        () => requestAnimationFrame(() => {
          clearTimeout(l), a();
        })
      );
    }), n = () => {
      if (!["text/html", "application/xhtml+xml"].includes(document.contentType))
        throw new Error("This document type is not supported. Open an HTML webpage.");
      const a = document.documentElement, d = document.body;
      return {
        width: innerWidth,
        height: innerHeight,
        documentWidth: Math.max(a.scrollWidth, d?.scrollWidth ?? 0),
        documentHeight: Math.max(a.scrollHeight, d?.scrollHeight ?? 0, innerHeight),
        scrollX,
        scrollY,
        dpr: devicePixelRatio,
        visualScale: visualViewport?.scale ?? 1
      };
    }, c = async () => {
      await r();
      const a = Array.from(document.images).filter((l) => {
        const u = l.getBoundingClientRect();
        return u.bottom > 0 && u.top < innerHeight && !l.complete;
      });
      let d;
      try {
        await Promise.race([
          Promise.all(a.map((l) => l.decode().catch(() => {
          }))),
          new Promise((l) => {
            d = setTimeout(l, 1e3);
          })
        ]);
      } finally {
        clearTimeout(d);
      }
      await r();
    };
    if (e.action === "restore")
      return o.__captureFlowPage?.id === t && o.__captureFlowPage.cleanup(), o.__captureFlowSelection?.id === t && o.__captureFlowSelection.cleanup(), await r(), { ok: !0, value: n() };
    if (e.action === "inspect") return { ok: !0, value: n() };
    if (e.action === "prepare") {
      if (o.__captureFlowPage) throw new Error("A capture is already preparing this page.");
      const a = n();
      if (a.documentWidth > a.width + 2)
        throw new Error(
          "Full-page capture currently supports vertical pages. Use a selected area for horizontally scrolling pages."
        );
      if (a.documentHeight <= a.height + 2 && Array.from(document.querySelectorAll("body *")).some((T) => {
        const z = T.getBoundingClientRect(), Se = getComputedStyle(T);
        return /auto|scroll/.test(Se.overflowY) && T.scrollHeight > T.clientHeight + 50 && z.width * z.height > innerWidth * innerHeight * 0.5;
      }))
        throw new Error(
          "This page scrolls inside a container. Use Visible area or Selected area."
        );
      const d = new CSSStyleSheet();
      d.replaceSync(
        "html,body,*{scroll-behavior:auto!important;scroll-snap-type:none!important;overflow-anchor:none!important;animation-play-state:paused!important;transition:none!important;caret-color:transparent!important}*::-webkit-scrollbar{display:none!important}"
      ), document.adoptedStyleSheets = [...document.adoptedStyleSheets, d];
      const l = document.createElement("div");
      l.style.cssText = "position:fixed!important;right:20px!important;bottom:20px!important;z-index:2147483647!important;display:block!important;";
      const u = l.attachShadow({ mode: "closed" }), w = new CSSStyleSheet();
      w.replaceSync(
        ":host{all:initial}div{font:13px Segoe UI,sans-serif;background:#191c22;color:#eff1f5;border:1px solid #b6a2ff;border-radius:12px;padding:14px;box-shadow:0 8px 30px #0005}button{background:#b6a2ff;border:0;border-radius:6px;padding:6px 10px;margin-left:12px;cursor:pointer;color:#191c22}"
      ), u.adoptedStyleSheets = [w];
      const g = document.createElement("span");
      g.textContent = "CaptureFlow · preparing…";
      const f = document.createElement("div"), A = document.createElement("button");
      A.textContent = "Cancel", f.append(g, A), u.append(f), document.documentElement.append(l);
      const U = /* @__PURE__ */ new Map(), I = Array.from(document.querySelectorAll("video")).filter(
        (h) => !h.paused
      );
      I.forEach((h) => h.pause());
      let _;
      const v = (h) => {
        p(), chrome.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: t,
          ...h ? { error: h } : {}
        }).catch(() => {
        });
      }, S = (h) => h.preventDefault(), L = (h) => {
        h.key === "Escape" ? (h.preventDefault(), v()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(h.key) && h.preventDefault();
      }, p = () => {
        clearTimeout(_), l.remove(), document.adoptedStyleSheets = document.adoptedStyleSheets.filter((h) => h !== d), U.forEach((h, T) => {
          h.value ? T.style.setProperty("visibility", h.value, h.priority) : T.style.removeProperty("visibility");
        }), window.removeEventListener("wheel", S, !0), window.removeEventListener("touchmove", S, !0), window.removeEventListener("keydown", L, !0), window.scrollTo({ left: a.scrollX, top: a.scrollY, behavior: "instant" }), I.forEach((h) => {
          h.play().catch(() => {
          });
        }), o.__captureFlowPage?.id === t && delete o.__captureFlowPage;
      }, m = () => {
        clearTimeout(_), _ = setTimeout(
          () => v("Capture stopped responding. The original page has been restored."),
          2e4
        );
      };
      o.__captureFlowPage = { id: t, cleanup: p, touch: m, hidden: U, hud: l, label: g, anchors: [] }, A.addEventListener("click", () => v()), window.addEventListener("wheel", S, { capture: !0, passive: !1 }), window.addEventListener("touchmove", S, { capture: !0, passive: !1 }), window.addEventListener("keydown", L, !0), m(), window.scrollTo({ left: 0, top: 0, behavior: "instant" });
      try {
        return await c(), await r(), { ok: !0, value: n() };
      } catch (h) {
        throw p(), h;
      }
    }
    if (e.action === "hideHud" || e.action === "showHud") {
      const a = o.__captureFlowPage;
      if (a?.id === t) {
        if (a.touch(), e.action === "showHud") {
          const d = /* @__PURE__ */ new Set();
          if (typeof document.elementsFromPoint == "function")
            for (const l of [innerWidth * 0.2, innerWidth * 0.5, innerWidth * 0.8])
              for (const u of [innerHeight * 0.25, innerHeight * 0.55, innerHeight * 0.85]) {
                const w = document.elementsFromPoint(l, u).find(
                  (f) => f !== a.hud && f !== document.documentElement && f !== document.body
                );
                if (!w) continue;
                let g = !1;
                for (let f = w; f; f = f.parentElement)
                  if (["fixed", "sticky"].includes(getComputedStyle(f).position)) {
                    g = !0;
                    break;
                  }
                g || d.add(w);
              }
          a.anchors = [...d].map((l) => {
            const u = l.getBoundingClientRect();
            return { element: l, top: u.top + scrollY, height: u.height };
          });
        }
        a.hud.style.setProperty(
          "display",
          e.action === "hideHud" ? "none" : "block",
          "important"
        ), e.action === "hideHud" && await r();
      }
      return { ok: !0, value: n() };
    }
    if (e.action !== "step") throw new Error("Unsupported page action.");
    const i = o.__captureFlowPage;
    if (!i || i.id !== t)
      throw new Error("The page capture expired. Please try again.");
    const s = () => {
      for (const a of i.anchors) {
        const d = a.element.getBoundingClientRect();
        if (!a.element.isConnected || Math.abs(d.top + scrollY - a.top) > 1 || Math.abs(d.height - a.height) > 1)
          throw new Error(
            "Content already captured shifted while loading. Wait for the page to stabilize, then retry."
          );
      }
    };
    return s(), i.touch(), i.label.textContent = "CaptureFlow · " + Math.round(e.progress) + "%", i.hud.style.setProperty("display", "block", "important"), e.hideSticky && Array.from(document.querySelectorAll("body *")).forEach((a) => {
      const d = getComputedStyle(a).position;
      (d === "fixed" || d === "sticky") && !i.hidden.has(a) && (i.hidden.set(a, {
        value: a.style.getPropertyValue("visibility"),
        priority: a.style.getPropertyPriority("visibility")
      }), a.style.setProperty("visibility", "hidden", "important"));
    }), window.scrollTo({ left: 0, top: e.y, behavior: "instant" }), await c(), s(), await r(), { ok: !0, value: n() };
  } catch (o) {
    return {
      ok: !1,
      error: o instanceof Error ? o.message : "The page could not be prepared."
    };
  }
}
function Vt(e) {
  if (typeof e != "string" || !e)
    throw new Error("Chrome returned an empty full-page image.");
  const t = Uint8Array.from(atob(e.slice(0, 44)), (c) => c.charCodeAt(0));
  if (t.length < 24 || ![137, 80, 78, 71, 13, 10, 26, 10].every((c, i) => t[i] === c))
    throw new Error("Chrome returned an invalid full-page PNG.");
  const o = new DataView(t.buffer), r = o.getUint32(16), n = o.getUint32(20);
  return ge(r, n), { width: r, height: n, data: e };
}
async function zt(e) {
  const t = { tabId: e.sourceTabId };
  let o = !1;
  const r = (c = !1) => chrome.scripting.executeScript({
    target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
    func: Wt,
    args: [e.id, c]
  }), n = async () => {
    const i = (await chrome.scripting.executeScript({
      target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
      func: He,
      args: [{ action: "inspect" }, e.id]
    }))[0]?.result;
    if (!i?.ok) throw new Error(i && !i.ok ? i.error : "The page is unavailable.");
    return i.value;
  };
  try {
    await chrome.debugger.attach(t, "1.3"), o = !0, await r();
    const c = await n(), i = async () => (await chrome.debugger.sendCommand(t, "Page.getLayoutMetrics")).cssContentSize, s = (l, u) => !!u && ["x", "y", "width", "height"].every(
      (w) => Math.abs(l[w] - u[w]) <= 1
    );
    let a = await i();
    const d = Date.now();
    for (let l = 0; l < 3; l++) {
      if (!a || ![a.x, a.y, a.width, a.height].every(Number.isFinite) || a.width < 1 || a.height < 1)
        throw new Error("Chrome could not measure this page for a full-page screenshot.");
      if (a.width > c.width + 2)
        throw new Error(
          "Horizontal scrolling pages are not supported. Use a selected-area capture."
        );
      ge(Math.ceil(a.width * c.dpr), Math.ceil(a.height * c.dpr));
      const u = [], w = Math.max(1, Math.floor(Math.min(c.height, 2048 / c.dpr)));
      if (Math.ceil(a.height / w) > 120)
        throw new Error(
          "This page needs too many full-page sections. Use a selected-area capture."
        );
      let g = 0, f = 0, A = 0, U = 0;
      for (let v = 0; v < a.height; v += w) {
        if (Date.now() - d > 2e4)
          throw new Error("The full-page renderer timed out. Try a smaller capture.");
        const S = Math.min(w, a.height - v);
        let L;
        const p = await Promise.race([
          chrome.debugger.sendCommand(t, "Page.captureScreenshot", {
            format: "png",
            fromSurface: !0,
            captureBeyondViewport: !0,
            clip: { x: a.x, y: a.y + v, width: a.width, height: S, scale: 1 }
          }),
          new Promise((z, Se) => {
            L = setTimeout(
              () => Se(new Error("The full-page renderer timed out. Try a smaller capture.")),
              Math.max(1, 2e4 - (Date.now() - d))
            );
          })
        ]).finally(() => clearTimeout(L)), m = Vt(p?.data);
        g || (g = m.width / a.width, f = m.width, A = Math.round(a.height * g), ge(f, A));
        const h = Math.round(v * g), T = Math.round((v + S) * g);
        if (m.width !== f || Math.abs(m.height - (T - h)) > 1)
          throw new Error("Chrome returned an incomplete full-page section. Please retry.");
        if (U += m.data.length, U > 48 * 1024 * 1024)
          throw new Error("The full-page image needs too much memory. Try a smaller capture.");
        u.push({ dataUrl: "data:image/png;base64," + m.data, y: h, width: f, height: T - h });
      }
      const I = await i();
      if (!s(a, I)) {
        a = I;
        continue;
      }
      const _ = await n();
      return { tiles: u, width: f, height: A, viewport: _ };
    }
    throw new Error(
      "The document keeps changing size. Pause live updates or use a visible/selected screenshot."
    );
  } catch (c) {
    const i = c instanceof Error ? c.message : String(c);
    throw /already attached|another debugger|DevTools/i.test(i) ? new Error(
      "Close DevTools or another debugger on this tab, then retry full-page capture."
    ) : new Error(i || "Chrome could not capture the full page without scrolling.");
  } finally {
    try {
      await r(!0);
    } catch {
    }
    if (o)
      try {
        await chrome.debugger.detach(t);
      } catch {
      }
  }
}
const ye = "captureflow.capture.v1", Yt = "captureflow/capture/v1", E = (e) => !!e && ["starting", "selecting", "capturing"].includes(e.status);
function qt(e) {
  try {
    const t = window;
    t.__captureFlowSelection?.cleanup();
    const o = document.activeElement instanceof HTMLElement ? document.activeElement : null, r = document.createElement("div");
    r.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;";
    const n = r.attachShadow({ mode: "closed" }), c = new CSSStyleSheet();
    c.replaceSync(
      ":host{all:initial}.overlay{position:fixed;inset:0;background:#0008;cursor:crosshair;touch-action:none;user-select:none;font:13px Segoe UI,sans-serif}.selection{position:absolute;display:none;border:2px solid #b6a2ff;box-sizing:border-box;box-shadow:0 0 0 99999px #0008;pointer-events:none}.dimensions{position:absolute;left:0;top:4px;padding:4px 7px;background:#191c22;color:white;white-space:nowrap;border-radius:4px;pointer-events:none}"
    ), n.adoptedStyleSheets = [c];
    const i = document.createElement("div");
    i.className = "overlay", i.tabIndex = 0, i.setAttribute("role", "dialog"), i.setAttribute(
      "aria-label",
      "Drag to capture an area. Release to capture. Escape to cancel."
    );
    const s = document.createElement("div");
    s.className = "selection";
    const a = document.createElement("div");
    a.className = "dimensions", s.append(a), i.append(s), n.append(i), document.documentElement.append(r);
    const d = {
      width: innerWidth,
      height: innerHeight,
      scrollX,
      scrollY,
      dpr: devicePixelRatio
    };
    let l = null, u = { x: 0, y: 0, width: 0, height: 0 }, w = !1, g;
    const f = (p) => p.preventDefault(), A = () => {
      clearTimeout(g), r.remove(), window.removeEventListener("keydown", v, !0), window.removeEventListener("resize", I), window.removeEventListener("scroll", I, !0), window.removeEventListener("wheel", f, !0), window.removeEventListener("touchmove", f, !0), t.__captureFlowSelection?.id === e && delete t.__captureFlowSelection, o?.focus({ preventScroll: !0 });
    }, U = (p) => {
      w || (w = !0, A(), chrome.runtime.sendMessage({
        channel: "captureflow/capture/v1",
        type: "PAGE_CANCEL",
        id: e,
        ...p ? { error: p } : {}
      }).catch(() => {
      }));
    }, I = () => U("The viewport changed during selection. Please select the area again."), _ = async () => {
      if (w || u.width < 2 || u.height < 2) return;
      if (innerWidth !== d.width || innerHeight !== d.height || scrollX !== d.scrollX || scrollY !== d.scrollY || devicePixelRatio !== d.dpr) {
        I();
        return;
      }
      w = !0;
      const p = { ...u };
      A();
      try {
        await new Promise((h, T) => {
          const z = setTimeout(
            () => T(
              new Error(
                "The source page stopped rendering. Keep its tab and window visible, then retry."
              )
            ),
            1e3
          );
          requestAnimationFrame(
            () => requestAnimationFrame(() => {
              clearTimeout(z), h();
            })
          );
        });
        const m = await chrome.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "SELECTED",
          id: e,
          rect: p,
          viewport: {
            width: innerWidth,
            height: innerHeight,
            documentWidth: document.documentElement.scrollWidth,
            documentHeight: Math.max(document.documentElement.scrollHeight, innerHeight),
            scrollX,
            scrollY,
            dpr: devicePixelRatio,
            visualScale: visualViewport?.scale ?? 1
          }
        });
        if (!m?.ok) throw new Error(m?.error ?? "The selected area could not be captured.");
      } catch (m) {
        chrome.runtime.sendMessage({
          channel: "captureflow/capture/v1",
          type: "PAGE_CANCEL",
          id: e,
          error: m instanceof Error ? m.message : "The selected area could not be captured."
        }).catch(() => {
        });
      }
    }, v = (p) => {
      p.key === "Escape" ? (p.preventDefault(), p.stopImmediatePropagation(), U()) : ["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(p.key) && p.preventDefault();
    }, S = (p, m) => Math.max(0, Math.min(m, p)), L = (p, m) => {
      l && (p = S(p, innerWidth), m = S(m, innerHeight), u = {
        x: Math.min(p, l.x),
        y: Math.min(m, l.y),
        width: Math.abs(p - l.x),
        height: Math.abs(m - l.y)
      }, s.style.display = u.width && u.height ? "block" : "none", Object.assign(s.style, {
        left: u.x + "px",
        top: u.y + "px",
        width: u.width + "px",
        height: u.height + "px"
      }), a.textContent = Math.round(u.width) + " × " + Math.round(u.height) + " px", i.style.background = u.width ? "transparent" : "#0008");
    };
    return i.addEventListener("pointerdown", (p) => {
      p.button !== 0 || w || (p.preventDefault(), i.setPointerCapture(p.pointerId), l = {
        x: S(p.clientX, innerWidth),
        y: S(p.clientY, innerHeight),
        pointerId: p.pointerId
      }, L(p.clientX, p.clientY));
    }), i.addEventListener("pointermove", (p) => {
      l?.pointerId === p.pointerId && L(p.clientX, p.clientY);
    }), i.addEventListener("pointerup", (p) => {
      !l || l.pointerId !== p.pointerId || p.button !== 0 || (L(p.clientX, p.clientY), l = null, _());
    }), i.addEventListener("pointercancel", () => {
      l = null, u = { x: 0, y: 0, width: 0, height: 0 }, s.style.display = "none", i.style.background = "#0008";
    }), window.addEventListener("keydown", v, !0), window.addEventListener("resize", I), window.addEventListener("scroll", I, !0), window.addEventListener("wheel", f, { capture: !0, passive: !1 }), window.addEventListener("touchmove", f, { capture: !0, passive: !1 }), t.__captureFlowSelection = { id: e, cleanup: A }, g = setTimeout(() => U("Selection timed out. Please try again."), 12e4), i.focus({ preventScroll: !0 }), { ok: !0 };
  } catch (t) {
    return {
      ok: !1,
      error: t instanceof Error ? t.message : "Selection is unavailable."
    };
  }
}
let xe = !1, Pe = !1;
const Ue = "captureflow.lastFrameAt";
async function P() {
  return (await chrome.storage.session.get(ye))[ye] ?? null;
}
async function O(e) {
  await chrome.storage.session.set({ [ye]: e });
}
async function X(e) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: "#7656c9" }), await chrome.action.setBadgeText({
      text: E(e) ? e.status === "selecting" ? "SEL" : e.progress + "%" : ""
    });
  } catch {
  }
}
async function j(e) {
  const t = await chrome.tabs.get(e.sourceTabId).catch(() => {
    throw new Error("The source tab was closed during capture.");
  });
  if (!t.active || t.windowId !== e.windowId)
    throw new Error("The source tab is no longer active. Keep it selected until capture finishes.");
  if (t.url !== e.sourceUrl)
    throw new Error("The source page navigated during capture. Please try again.");
  return t;
}
async function G(e, t) {
  const r = (await chrome.scripting.executeScript({
    target: { tabId: e.sourceTabId, documentIds: [e.documentId] },
    func: He,
    args: [t, e.id]
  }))[0]?.result;
  if (!r) throw new Error("The page is no longer available.");
  if (!r.ok) throw new Error(r.error);
  return De(r.value), r.value;
}
async function Fe(e) {
  try {
    await G(e, { action: "restore" });
  } catch {
  }
}
async function D(e, t, o) {
  const r = await P();
  if (!r || r.id !== e.id || !E(r)) return;
  const n = { ...r, status: t, message: o, updatedAt: Date.now() };
  await O(n), await X(n), await Fe(n);
}
async function ne(e) {
  const t = await P();
  if (!t || t.id !== e)
    throw new Error("This capture session has expired. Start a new capture.");
  return t;
}
function Y(e, t) {
  return e.id === chrome.runtime.id && e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
async function Qt(e, t) {
  if (t.id !== chrome.runtime.id) throw new Error("Untrusted capture sender.");
  if (e.type === "GET") {
    if (!Y(t, "popup.html") && !Y(t, "capture.html"))
      throw new Error("Capture state is private.");
    return P();
  }
  if (e.type === "START") {
    if (!Y(t, "popup.html"))
      throw new Error("Start capture from the CaptureFlow popup.");
    if (!["visible", "selected", "full"].includes(e.mode))
      throw new Error("Unknown capture mode.");
    if (xe) throw new Error("A capture is already starting.");
    xe = !0;
    let r = null;
    try {
      const n = await P();
      if (E(n)) {
        if (n?.coordinatorTabId !== null ? await chrome.tabs.get(n.coordinatorTabId).then(
          () => !0,
          () => !1
        ) : !1)
          throw new Error("A capture is already running. Cancel it before starting another.");
        n && await D(n, "error", "The capture tab was closed.");
      }
      const c = await Le(t);
      if (c?.id === void 0 || !c.url) throw new Error("No active webpage is available.");
      ee(c.url), we(await he(), "screenshot");
      const s = (await chrome.scripting.executeScript({
        target: { tabId: c.id },
        func: He,
        args: [{ action: "inspect" }, "initial"]
      }))[0];
      if (s?.result && !s.result.ok) throw new Error(s.result.error);
      if (!s?.result?.ok || !s.documentId)
        throw new Error("This page cannot be captured. Reload the webpage and try again.");
      De(s.result.value);
      const a = e.mode;
      r = {
        id: crypto.randomUUID(),
        mode: a,
        status: "starting",
        sourceTabId: c.id,
        windowId: c.windowId,
        documentId: s.documentId,
        sourceUrl: c.url,
        title: c.title ?? "Screenshot",
        coordinatorTabId: null,
        progress: 0,
        message: "Preparing capture…",
        updatedAt: Date.now()
      }, await O(r);
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("capture.html") + "?id=" + r.id,
        active: !1,
        windowId: c.windowId
      });
      if (d.id === void 0) throw new Error("Could not open the screenshot workspace.");
      return r = { ...r, coordinatorTabId: d.id }, await O(r), await X(r), r;
    } catch (n) {
      throw r && await D(
        r,
        "error",
        n instanceof Error ? n.message : "Could not start capture."
      ), n;
    } finally {
      xe = !1;
    }
  }
  const o = await ne(e.id);
  if (e.type === "SELECTED" || e.type === "PAGE_CANCEL") {
    if (t.tab?.id !== o.sourceTabId || t.documentId !== o.documentId)
      throw new Error("The selection came from another page.");
    if (!E(o)) return null;
    if (e.type === "PAGE_CANCEL")
      return await D(
        o,
        e.error ? "error" : "cancelled",
        e.error ?? "Capture cancelled."
      ), null;
    if (o.status !== "selecting" || o.mode !== "selected")
      throw new Error("This session is not selecting an area.");
    st(e.rect, e.viewport, e.viewport.width, e.viewport.height);
    const r = await G(o, { action: "inspect" });
    if (!Je(e.viewport, r))
      throw new Error("The page moved after selection. Select the area again.");
    return await O({
      ...o,
      selection: { rect: e.rect, viewport: e.viewport },
      status: "capturing",
      message: "Capturing selected area…",
      updatedAt: Date.now()
    }), null;
  }
  if (e.type === "CANCEL") {
    if (!Y(t, "popup.html") && t.tab?.id !== o.coordinatorTabId)
      throw new Error("Cannot cancel another capture.");
    return await D(o, "cancelled", "Capture cancelled."), null;
  }
  if (!Y(t, "capture.html") || t.tab?.id !== o.coordinatorTabId)
    throw new Error("This request does not belong to the active capture workspace.");
  if (e.type === "PAGE" && e.command.action === "restore")
    return await Fe(o), null;
  if (!E(o)) throw new Error(o.message || "The capture has ended.");
  if (e.type === "FAIL")
    return await D(o, "error", e.error.slice(0, 500)), null;
  if (e.type === "FINISH") {
    await Fe(o);
    const r = await ne(o.id);
    if (!E(r)) throw new Error(r.message);
    const n = {
      ...r,
      status: "complete",
      progress: 100,
      message: "Screenshot ready",
      updatedAt: Date.now()
    };
    return await ct("screenshot", o.id), await O(n), await X(n), await chrome.tabs.update(o.coordinatorTabId, { active: !0 }), null;
  }
  if (e.type === "PROGRESS") {
    const r = Math.max(0, Math.min(99, Math.round(e.progress)));
    if (!Number.isFinite(r)) throw new Error("Invalid capture progress.");
    const n = {
      ...o,
      status: "capturing",
      progress: r,
      message: e.message.slice(0, 200),
      updatedAt: Date.now()
    };
    return await O(n), await X(n), null;
  }
  if (e.type === "SELECT") {
    if (o.mode !== "selected" || o.status !== "starting")
      throw new Error("Selection is not available in this session.");
    await j(o), await O({
      ...o,
      status: "selecting",
      message: "Drag to select an area on the webpage.",
      updatedAt: Date.now()
    });
    const n = (await chrome.scripting.executeScript({
      target: { tabId: o.sourceTabId, documentIds: [o.documentId] },
      func: qt,
      args: [o.id]
    }))[0]?.result;
    if (!n) throw new Error("Could not open the selection overlay.");
    if (!n.ok) throw new Error(n.error);
    return await X({ ...o, status: "selecting" }), null;
  }
  if (e.type === "PAGE") {
    if (!["inspect", "prepare", "step"].includes(e.command.action))
      throw new Error("Unsupported page operation.");
    if (e.command.action === "step" && (!Number.isFinite(e.command.y) || e.command.y < 0))
      throw new Error("Invalid scroll position.");
    return await j(o), G(o, e.command);
  }
  if (e.type === "FULL_PAGE") {
    if (o.mode !== "full")
      throw new Error("Full-page capture is not available in this session.");
    await j(o);
    const r = await zt(o);
    await j(o);
    const n = await ne(o.id);
    if (!E(n)) throw new Error(n.message);
    return r;
  }
  if (e.type === "FRAME") {
    if (Pe) throw new Error("Another screenshot frame is being captured.");
    Pe = !0;
    try {
      const r = Number((await chrome.storage.session.get(Ue))[Ue] ?? 0), n = Math.max(0, 650 - (Date.now() - r));
      n && await new Promise((d) => setTimeout(d, n)), await j(o);
      const c = await G(o, {
        action: o.mode === "full" ? "hideHud" : "inspect"
      });
      await chrome.storage.session.set({ [Ue]: Date.now() });
      const i = await chrome.tabs.captureVisibleTab(o.windowId, { format: "png" });
      await j(o);
      const s = await G(o, { action: "inspect" }), a = await ne(o.id);
      if (!E(a)) throw new Error(a.message);
      if (!Je(c, s) || c.documentHeight !== s.documentHeight)
        throw new Error(
          "The page moved or resized during a frame. Please retry once the page is stable."
        );
      return { dataUrl: i, viewport: s };
    } finally {
      if (o.mode === "full")
        try {
          await G(o, { action: "showHud" });
        } catch {
        }
      Pe = !1;
    }
  }
  throw new Error("Unknown capture command.");
}
function Xt(e) {
  if (!e || typeof e != "object") throw new Error("Invalid capture message.");
  const t = e;
  if (t.type === "GET") return { type: "GET" };
  if (t.type === "START" && ["visible", "selected", "full"].includes(String(t.mode)))
    return { type: "START", mode: t.mode };
  if (typeof t.id != "string" || t.id.length > 100)
    throw new Error("Invalid capture session.");
  if (["CANCEL", "SELECT", "FRAME", "FULL_PAGE", "FINISH"].includes(String(t.type)))
    return {
      type: t.type,
      id: t.id
    };
  if (t.type === "PAGE" && t.command && typeof t.command == "object") {
    const o = t.command;
    if (["inspect", "prepare", "restore"].includes(String(o.action)))
      return {
        type: "PAGE",
        id: t.id,
        command: { action: o.action }
      };
    if (o.action === "step" && typeof o.y == "number" && Number.isFinite(o.y) && typeof o.progress == "number" && Number.isFinite(o.progress) && typeof o.hideSticky == "boolean")
      return {
        type: "PAGE",
        id: t.id,
        command: {
          action: "step",
          y: o.y,
          progress: o.progress,
          hideSticky: o.hideSticky
        }
      };
  }
  if (t.type === "PROGRESS" && typeof t.progress == "number" && typeof t.message == "string")
    return { type: "PROGRESS", id: t.id, progress: t.progress, message: t.message };
  if (t.type === "FAIL" && typeof t.error == "string")
    return { type: "FAIL", id: t.id, error: t.error };
  if (t.type === "PAGE_CANCEL" && (t.error === void 0 || typeof t.error == "string"))
    return {
      type: "PAGE_CANCEL",
      id: t.id,
      ...typeof t.error == "string" ? { error: t.error } : {}
    };
  if (t.type === "SELECTED") {
    const o = t.rect, r = t.viewport;
    return st(o, r, r?.width, r?.height), { type: "SELECTED", id: t.id, rect: o, viewport: r };
  }
  throw new Error("Unsupported capture message.");
}
async function Jt(e) {
  const t = await P();
  t && (t.coordinatorTabId === e ? (E(t) && await D(t, "cancelled", "The capture workspace was closed."), (await P())?.id === t.id && await chrome.storage.session.remove(ye)) : t.sourceTabId === e && E(t) && await D(t, "error", "The source tab was closed during capture."));
}
async function W() {
  return (await chrome.storage.session.get(Ne))[Ne] ?? null;
}
async function lt(e) {
  if (e && ["starting", "recording", "paused", "stopping"].includes(e.status))
    await chrome.action.setBadgeBackgroundColor({
      color: e.status === "paused" ? "#a16207" : "#dc2626"
    }), await chrome.action.setBadgeText({
      text: e.status === "paused" ? "Ⅱ" : e.status === "recording" ? "REC" : "…"
    });
  else {
    const t = await P();
    E(t) || await chrome.action.setBadgeText({ text: "" });
  }
}
async function y(e) {
  return await chrome.storage.session.set({ [Ne]: e }), await lt(e), e;
}
function F(e, t) {
  return e.url?.split("?")[0] === chrome.runtime.getURL(t);
}
function $t(e) {
  if (e.id !== chrome.runtime.id || !["popup.html", "recording.html", "offscreen.html", "controls.html"].some(
    (t) => F(e, t)
  ))
    throw new Error("Untrusted recording request.");
}
function $e(e, t) {
  return t.owner === "offscreen" ? F(e, "offscreen.html") && e.tab === void 0 : F(e, "recording.html") && e.tab?.id === t.controllerTabId;
}
async function Zt(e) {
  const t = await W();
  if (!t || t.id !== e)
    throw new Error("This recording session has expired. Open a new recorder.");
  return t;
}
async function je(e) {
  if (e.owner === "offscreen")
    return (await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL("offscreen.html")]
    })).length > 0;
  if (e.controllerTabId === null) return !1;
  try {
    return (await chrome.runtime.getContexts({
      contextTypes: ["TAB"],
      tabIds: [e.controllerTabId],
      documentUrls: [chrome.runtime.getURL("recording.html?id=" + e.id)]
    })).length > 0;
  } catch {
    return !1;
  }
}
async function H(e, t, o = {}) {
  const r = await chrome.runtime.sendMessage({
    channel: Kt,
    target: e.owner === "offscreen" ? "offscreen" : "page:" + e.id,
    type: t,
    id: e.id,
    ...o
  });
  if (!r?.ok)
    throw new Error(
      r?.error ?? "The recording host is unavailable. Open the recorder to recover saved chunks."
    );
  return r.data;
}
async function ut(e = "tab") {
  if ((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL("offscreen.html")]
  })).length) {
    if (e === "tab") return;
    await chrome.offscreen.closeDocument();
  }
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: e === "tab" ? ["USER_MEDIA"] : ["USER_MEDIA", "DISPLAY_MEDIA"],
    justification: "Record the explicitly requested tab, window or screen and audio while the popup is closed."
  });
}
async function Ze(e) {
  const t = await chrome.tabs.create({
    url: chrome.runtime.getURL("recording.html?preview=" + encodeURIComponent(e)),
    active: !0
  });
  t.id !== void 0 && await Dt(e, t.id);
}
async function be(e, t) {
  let o = await me(e.id);
  if (o) {
    o = {
      ...o,
      bytes: (await _t(e.id, o.mimeType)).size,
      warning: o.complete ? o.warning : t + " Only previously committed chunks may be recoverable."
    };
    try {
      await Nt(o);
    } catch {
    }
  }
  return y({
    ...e,
    status: o?.bytes ? "complete" : "error",
    elapsedMs: o?.durationMs ?? Bt(e),
    clockStartedAt: null,
    error: o?.bytes ? "" : t,
    warning: o?.bytes ? t : e.warning
  });
}
async function er(e, t) {
  if ($t(t), !e || typeof e != "object") throw new Error("Invalid recorder request.");
  const o = e;
  if (o.type === "GET") return Ee();
  if (o.type === "START_POPUP") {
    if (!F(t, "popup.html"))
      throw new Error("Start recording from the CaptureFlow popup.");
    const n = Ae(ke(o.options)), c = await Ee();
    if (C(c))
      throw new Error("A recording is already active. Stop or cancel it before starting another.");
    if (we(await he(), "video"), E(await P())) throw new Error("Finish the screenshot before recording.");
    const i = await Le(t);
    if (n.mode === "tab") {
      if (i?.id === void 0 || !i.url) throw new Error("Select a webpage before recording.");
      ee(i.url);
    }
    const s = await qe(), a = {
      id: crypto.randomUUID(),
      options: n,
      popupStart: !0,
      owner: "offscreen",
      controllerTabId: null,
      sourceTabId: i?.id ?? null,
      title: n.mode === "tab" ? i?.title ?? "Tab recording" : n.mode === "window" ? "Window recording" : "Screen recording",
      sourceUrl: n.mode === "tab" ? i?.url ?? "" : "",
      createdAt: Date.now(),
      status: "starting",
      elapsedMs: 0,
      clockStartedAt: null,
      hasMicrophone: !1,
      microphone: !1,
      hasAudio: !1,
      audio: !1,
      bytes: 0,
      warning: "",
      error: "",
      retention: s.autoSave ? "saved" : "temporary"
    };
    return await y(a), rr(a);
  }
  if (o.type === "PREPARE") {
    if (!F(t, "popup.html"))
      throw new Error("Open the recorder from the extension popup.");
    const n = Ae(ke(o.options)), c = await W();
    if (C(c))
      if (c?.controllerTabId !== null && c?.controllerTabId !== void 0)
        try {
          return await chrome.tabs.update(c.controllerTabId, { active: !0 }), c;
        } catch {
          if (c.status !== "setup" && await je(c)) return c;
          await be(c, "The recorder page was closed.");
        }
      else throw new Error("Another recording is starting.");
    if (E(await P()))
      throw new Error("Finish the screenshot capture before starting a recording.");
    const i = await Le(t);
    if (n.mode === "tab") {
      if (i?.id === void 0 || !i.url)
        throw new Error("Select a webpage before recording a tab.");
      ee(i.url);
    }
    const s = crypto.randomUUID(), a = {
      id: s,
      options: n,
      owner: n.mode === "tab" ? "offscreen" : "page",
      controllerTabId: null,
      sourceTabId: i?.id ?? null,
      title: n.mode === "tab" ? i?.title ?? "Tab recording" : n.mode === "window" ? "Window recording" : "Screen recording",
      sourceUrl: n.mode === "tab" ? i?.url ?? "" : "",
      createdAt: Date.now(),
      status: "setup",
      elapsedMs: 0,
      clockStartedAt: null,
      hasMicrophone: !1,
      microphone: !1,
      hasAudio: !1,
      audio: !1,
      bytes: 0,
      warning: "",
      error: ""
    };
    await y(a);
    try {
      const d = await chrome.tabs.create({
        url: chrome.runtime.getURL("recording.html?id=" + s),
        active: !0
      });
      if (d.id === void 0) throw new Error("Chrome could not open the recorder.");
      return y({ ...a, controllerTabId: d.id });
    } catch (d) {
      throw await y({ ...a, status: "error", error: "Chrome could not open the recorder." }), d;
    }
  }
  if (o.type === "OPEN_PREVIEW") {
    if (typeof o.id != "string" || !await me(o.id))
      throw new Error("This saved recording is unavailable.");
    return await Ze(o.id), null;
  }
  const r = await Zt(o.id);
  if (o.type === "OPEN" && r.popupStart && C(r))
    return y(await ze(r));
  if (o.type === "OPEN") {
    if (r.controllerTabId !== null)
      try {
        return await chrome.tabs.update(r.controllerTabId, { active: !0 }), r;
      } catch {
      }
    const n = await chrome.tabs.create({
      url: chrome.runtime.getURL("recording.html?id=" + r.id),
      active: !0
    });
    return y({ ...r, controllerTabId: n.id ?? null });
  }
  if (o.type === "BEGIN") {
    if (!F(t, "recording.html") || t.tab?.id !== r.controllerTabId || !["setup", "error"].includes(r.status))
      throw new Error("This recording cannot start from this page or state.");
    if (E(await P())) throw new Error("Finish the screenshot before recording.");
    we(await he(), "video", r.id);
    const n = Ae(ke(o.options));
    if (n.mode !== r.options.mode)
      throw new Error("Open a new recorder to change source mode.");
    const c = await qe(), i = {
      ...r,
      options: n,
      retention: c.autoSave ? "saved" : "temporary",
      status: "starting",
      error: "",
      warning: ""
    };
    if (await y(i), n.mode === "tab")
      try {
        if (r.sourceTabId === null) throw new Error("The source tab is unavailable.");
        const s = await chrome.tabs.get(r.sourceTabId);
        ee(s.url ?? ""), await ut();
        const a = await chrome.tabCapture.getMediaStreamId({
          targetTabId: r.sourceTabId
        });
        await H(i, "START_TAB", { streamId: a, session: i });
      } catch (s) {
        await y({
          ...i,
          status: "error",
          error: s instanceof Error ? s.message : "Tab capture failed."
        });
        try {
          await chrome.offscreen.closeDocument();
        } catch {
        }
        throw s;
      }
    return i;
  }
  if (o.type === "UPDATE") {
    if (!$e(t, r))
      throw new Error("Only the current recording host may publish state.");
    if (!C(r)) return r;
    const n = o.snapshot;
    if (!n || !["starting", "recording", "paused", "stopping", "complete", "error"].includes(
      String(n.status)
    ) || !Number.isFinite(n.elapsedMs) || !Number.isFinite(n.bytes) || n.elapsedMs < 0 || n.bytes < 0 || !(n.clockStartedAt === null || Number.isFinite(n.clockStartedAt)) || !["audio", "hasAudio", "microphone", "hasMicrophone"].every(
      (i) => typeof n[i] == "boolean"
    ) || typeof n.warning != "string")
      throw new Error("Invalid recording state.");
    if (n.status === "recording" && r.status === "starting")
      try {
        await ct("video", r.id);
      } catch (i) {
        throw await H(r, "STOP", { reason: "Monthly usage could not be saved." }).catch(
          () => {
          }
        ), i;
      }
    let c = await y({
      ...r,
      status: n.status === "complete" ? "stopping" : n.status,
      elapsedMs: n.elapsedMs,
      clockStartedAt: n.clockStartedAt,
      bytes: n.bytes,
      microphone: !1,
      hasMicrophone: !1,
      audio: n.audio,
      hasAudio: n.hasAudio,
      warning: n.warning,
      error: n.status === "error" ? n.warning : ""
    });
    if (r.popupStart && n.status === "recording" && !r.controlsOpened)
      try {
        c = await y(await ze(c, !0));
      } catch (i) {
        c = await y({
          ...c,
          controlsOpened: !0,
          controlsError: i instanceof Error ? i.message : "Open recording controls from the extension popup."
        });
      }
    return n.status === "error" && await Ie(r), n.status === "error" && r.owner === "offscreen" && await chrome.offscreen.closeDocument(), c;
  }
  if (o.type === "COMPLETE") {
    if (!$e(t, r)) throw new Error("Only the current host may finish recording.");
    const n = await me(r.id);
    if (!n) throw new Error("The recording could not be saved locally.");
    const c = await y({
      ...r,
      status: n.bytes ? "complete" : "error",
      elapsedMs: n.durationMs,
      clockStartedAt: null,
      bytes: n.bytes,
      warning: n.warning,
      error: n.bytes ? "" : "No video data was saved."
    });
    try {
      await Ie(r), n.bytes && await Ze(r.id);
    } finally {
      ce(), r.owner === "offscreen" && await chrome.offscreen.closeDocument();
    }
    return c;
  }
  if (o.type === "FAIL") {
    if (!F(t, "recording.html") || t.tab?.id !== r.controllerTabId)
      throw new Error("Untrusted recording failure.");
    if (!["setup", "starting", "error"].includes(r.status))
      throw new Error("The recording is already running.");
    return y({
      ...r,
      status: "error",
      clockStartedAt: null,
      error: typeof o.error == "string" ? o.error : "Recording start failed."
    });
  }
  if (o.type === "CANCEL_SETUP") {
    if (!["setup", "error"].includes(r.status))
      throw new Error("Stop the active recording first.");
    return y({ ...r, status: "cancelled", error: "" });
  }
  if (["PIN_CONTROLS", "UNPIN_CONTROLS", "CLOSE_CONTROLS"].includes(String(o.type))) {
    if (!F(t, "controls.html") || t.tab?.id !== r.controlsTabId || r.controlsWindowId == null)
      throw new Error("Only this recording controls window may change its visibility.");
    return o.type === "PIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, { state: "minimized" }) : o.type === "UNPIN_CONTROLS" ? await chrome.windows.update(r.controlsWindowId, {
      state: "normal",
      focused: !0,
      width: 280,
      height: 106
    }) : await Ie(r), null;
  }
  if (o.type === "CONTROL") {
    if (!["PAUSE", "RESUME", "STOP", "AUDIO"].includes(String(o.command)))
      throw new Error("Unknown recording control.");
    if (!C(r) || r.status === "setup")
      throw new Error("No active recording is available.");
    if (o.command === "AUDIO" && typeof o.enabled != "boolean")
      throw new Error("Invalid audio toggle.");
    return H(r, String(o.command), { enabled: o.enabled === !0 });
  }
  throw new Error("Unknown recording request.");
}
async function tr(e) {
  const t = await W();
  if (!(!t || !C(t))) {
    if (t.controlsTabId === e) {
      await y({ ...t, controlsWindowId: null, controlsTabId: null });
      return;
    }
    if (t.sourceTabId === e && t.options.mode === "tab" && t.status !== "setup")
      try {
        await H(t, "STOP", { reason: "The source tab closed." });
      } catch {
        await be(t, "The source tab closed.");
      }
    else if (t.controllerTabId === e) {
      if (t.owner === "offscreen" && t.status !== "setup" && await je(t)) {
        await y({ ...t, controllerTabId: null });
        return;
      }
      await be(t, "The recorder tab closed.");
    }
  }
}
async function Ee() {
  let e = await W();
  if (e && C(e) && e.status !== "setup") {
    let t = !await je(e);
    if (!t && ["recording", "paused", "stopping"].includes(e.status))
      try {
        await H(e, "PING");
      } catch {
        t = !0;
      }
    t && (e = await be(e, "The recording host closed or was interrupted."));
  }
  return e;
}
async function rr(e) {
  try {
    if (await ut(e.options.mode), e.options.mode === "tab") {
      if (e.sourceTabId === null) throw new Error("The source tab is unavailable.");
      const t = await chrome.tabs.get(e.sourceTabId);
      ee(t.url ?? "");
      const o = await chrome.tabCapture.getMediaStreamId({
        targetTabId: e.sourceTabId
      });
      await H(e, "START_TAB", { streamId: o, session: e });
    } else await H(e, "START_DISPLAY", { session: e });
    return e;
  } catch (t) {
    await y({
      ...e,
      status: "error",
      clockStartedAt: null,
      error: t instanceof Error ? t.message : "Recording could not start."
    });
    try {
      await chrome.offscreen.closeDocument();
    } catch {
    }
    throw t;
  }
}
async function or(e = null) {
  return x(["screenshots", "recordings"], "readonly", (t, o) => {
    const r = t.objectStore("screenshots").getAll(), n = t.objectStore("recordings").getAll();
    let c = 0;
    const i = () => {
      if (++c !== 2) return;
      const s = [
        ...r.result,
        ...n.result.filter((a) => a.id !== e && a.bytes > 0 && a.retention !== "temporary").map((a) => ({
          id: a.id,
          kind: "recording",
          title: a.title,
          sourceUrl: a.sourceUrl ?? "",
          createdAt: a.createdAt,
          updatedAt: a.createdAt,
          bytes: a.bytes,
          durationMs: a.durationMs,
          complete: a.complete,
          warning: a.warning
        }))
      ];
      o(s.sort((a, d) => d.createdAt - a.createdAt || a.id.localeCompare(d.id)));
    };
    r.onsuccess = i, n.onsuccess = i;
  });
}
async function nr(e, t, o = null) {
  if (e === "recording" && t === o)
    throw new Error("Stop the active recording before deleting it.");
  await x(["screenshots", "recordings", "chunks", "assets"], "readwrite", (r) => {
    r.objectStore(e === "screenshot" ? "screenshots" : "recordings").delete(t), e === "recording" && Oe(r, t), fe(r, t);
  });
}
async function ir(e = null) {
  return x(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      let r = 0, n = 2;
      const c = t.objectStore("screenshots").openCursor(), i = t.objectStore("recordings").openCursor();
      c.onsuccess = () => {
        const s = c.result;
        if (!s) {
          --n || o(r);
          return;
        }
        fe(t, String(s.primaryKey)), s.delete(), r++, s.continue();
      }, i.onsuccess = () => {
        const s = i.result;
        if (!s) {
          --n || o(r);
          return;
        }
        const a = s.value;
        a.id !== e && a.retention !== "temporary" && (Oe(t, a.id), fe(t, a.id), s.delete(), r++), s.continue();
      };
    }
  );
}
async function ar(e = null) {
  return x(
    ["screenshots", "recordings", "chunks", "assets"],
    "readwrite",
    (t, o) => {
      const r = t.objectStore("screenshots").getAllKeys(), n = t.objectStore("recordings").getAllKeys();
      let c = 2;
      const i = () => {
        if (--c) return;
        const s = new Set([...r.result, ...n.result].map(String));
        e && s.add(e);
        let a = 0, d = 2;
        for (const l of ["chunks", "assets"]) {
          const u = t.objectStore(l).openKeyCursor();
          u.onsuccess = () => {
            const w = u.result;
            if (!w) {
              --d || o(a);
              return;
            }
            const g = w.primaryKey;
            s.has(g[0]) || (t.objectStore(l).delete(w.primaryKey), a++), w.continue();
          };
        }
      };
      r.onsuccess = i, n.onsuccess = i;
    }
  );
}
async function re(e = !1, t) {
  const o = t === void 0 ? await Ee() : null, r = t === void 0 ? C(o) ? o.id : null : t, n = new Set(r ? [r] : []);
  if (!e && (await Ft()).some((c) => c.retention === "temporary")) {
    for (const c of await chrome.runtime.getContexts({ contextTypes: ["TAB"] }))
      if (c.documentUrl)
        try {
          const i = new URL(c.documentUrl);
          if (i.protocol !== "chrome-extension:" || i.host !== chrome.runtime.id || i.pathname !== "/recording.html")
            continue;
          const s = i.searchParams.get("preview");
          s && n.add(s);
        } catch {
        }
  }
  return await Ht(n), await ar(r ?? null), r ?? null;
}
async function cr(e, t) {
  if (t.id !== chrome.runtime.id || !["popup.html", "capture.html", "recording.html", "history.html"].some(
    (c) => t.url?.split("?")[0] === chrome.runtime.getURL(c)
  ))
    throw new Error("History is private to CaptureFlow pages.");
  if (!e || typeof e != "object") throw new Error("Invalid history request.");
  const o = e, r = await Ee(), n = C(r) ? r.id : null;
  if (o.type === "LIST")
    return await re(!1, n), { items: await or(n), activeRecordingId: n };
  if (o.type === "DELETE") {
    if (!["screenshot", "recording"].includes(String(o.kind)) || typeof o.id != "string" || !o.id)
      throw new Error("Invalid history item.");
    await nr(o.kind, o.id, n);
  } else if (o.type === "CLEAR") {
    const c = await ir(n);
    return await re(!1, n), ce(), c;
  } else if (o.type === "KEEP_RECORDING") {
    if (typeof o.id != "string" || o.id === n)
      throw new Error("Finish recording before keeping it in history.");
    if (!(await me(o.id))?.bytes) throw new Error("This recording is unavailable.");
    const i = await Ot(o.id);
    return ce(), i;
  } else throw new Error("Unknown history request.");
  return ce(), null;
}
const dt = "captureflow/v1";
function sr(e) {
  if (!e || typeof e != "object") return !1;
  const t = e;
  return t.channel === dt && t.type === "GET_APP_INFO";
}
function lr(e, t, o, r) {
  return t !== o ? { ok: !1, error: "Untrusted message sender." } : sr(e) ? {
    ok: !0,
    data: {
      version: r,
      phase: 6,
      capabilities: [
        "preferences",
        "themes",
        "navigation",
        "screenshots",
        "annotations",
        "recording",
        "history"
      ]
    }
  } : { ok: !1, error: "Unsupported CaptureFlow message." };
}
function q(e) {
  const t = e instanceof Error ? e.message : "An unexpected error occurred.";
  return /quota|QUOTA_BYTES/i.test(t) ? "Local storage is full. Free some space and try again." : /receiving end|connection|message port|timed out/i.test(t) ? "Cannot reach CaptureFlow. Reload the extension in chrome://extensions and try again." : t;
}
function Ke() {
  let e = Promise.resolve();
  return (t) => {
    const o = e.then(t);
    return e = o.then(
      () => {
      },
      () => {
      }
    ), o;
  };
}
const V = Ke(), pt = V, et = Ke(), ur = Ke();
chrome.runtime.onMessage.addListener((e, t, o) => e && typeof e == "object" && "channel" in e && e.channel === ft ? !("type" in e) || e.type !== "OPEN" ? (o({ ok: !1, error: "Unknown window request." }), !1) : (ur(() => ht(t)).then(
  () => o({ ok: !0 }),
  (r) => o({ ok: !1, error: q(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === yt ? (("type" in e && e.type === "STATUS" ? We(e, t) : et(() => We(e, t))).then(
  (n) => o({ ok: !0, data: n }),
  (n) => o({ ok: !1, error: q(n) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Ct ? (et(() => kt(e, t)).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: q(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === xt ? (V(async () => (await k(), cr(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: Pt(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === jt ? (pt(async () => (await k(), er(e, t))).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: q(r) })
), !0) : e && typeof e == "object" && "channel" in e && e.channel === Yt ? (V(async () => {
  await k();
  const r = Xt(e);
  if (r.type === "START" && C(await W()))
    throw new Error("Finish or cancel the recorder before capturing screenshots.");
  const n = await Qt(r, t), c = await W();
  return C(c) && await lt(c), n;
}).then(
  (r) => o({ ok: !0, data: r }),
  (r) => o({ ok: !1, error: q(r) })
), !0) : (!e || typeof e != "object" || !("channel" in e) || e.channel !== dt || o(
  lr(e, t.id, chrome.runtime.id, chrome.runtime.getManifest().version)
), !1));
chrome.tabs.onRemoved.addListener((e) => {
  pt(async () => {
    await tr(e), await re();
  }).catch(console.error), V(() => Jt(e)).catch(console.error);
});
chrome.runtime.onStartup?.addListener(() => {
  V(() => re(!0)).catch(console.error);
});
chrome.runtime.onInstalled?.addListener(() => {
  chrome.storage.local.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" }), V(() => re(!0)).catch(console.error);
});
chrome.windows?.onFocusChanged?.addListener((e) => {
  wt(e).catch(() => {
  });
});

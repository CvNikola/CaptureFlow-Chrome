import"./entitlement-BPTjJvmL.js";import{c as o}from"./host-hNd4RBoC.js";import"./recording-BOeTvszc.js";import"./recordings-DPMUcQ8s.js";import"./recordingMessaging-AFIy-b5k.js";o("offscreen");
